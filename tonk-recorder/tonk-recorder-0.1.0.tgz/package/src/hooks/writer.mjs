// R3 write path. INTEGRATION: R2 (src/writer/tool.mjs, landed on master)
// owns notation building (buildChangeNotation), the 64 KB split (splitDiff),
// the writer lock (withLock/lockPathFor) and checkpoint sync (checkpointSync).
// We reuse those; the actual `tonk eval --no-sync` goes through our tonk.mjs
// with an explicit --space (R2's writeChange re-resolves the binding via a
// `tonk status` subprocess, which may fetch the upstream — not allowed on
// the per-turn no-network path, SPEC §6.4). Session records (no R2
// equivalent yet) are built here per contracts/records.md.

import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { evalNoSync, blobAdd, queryJson } from "./tonk.mjs";
import { buildChangeNotation, splitDiff, withLock, lockPathFor } from "../writer/tool.mjs";
import { scanSecrets } from "../snapshot/tool.mjs";

const y = (v) => JSON.stringify(String(v));
const kw = (v) => `:${v}`;
const ynat = (v) => String(v ?? 0);

export { buildChangeNotation, splitDiff };

/** Write one change record: idempotent by (session, turn), secret-scanned,
 *  blob-split, ONE `tonk eval --no-sync` under the per-space writer lock. */
export async function writeChange(space, rec, env, root) {
  const existing = queryJson(space, "change", [`session=${rec.session}`, `turn=${rec.turn}`], env);
  if (existing.length > 0) return { written: false, skipped: true, redacted: rec.redacted };

  const scan = scanSecrets(rec.diff || "");
  const split = splitDiff(scan.text); // R2: { inline, bytes }
  let diff = scan.text;
  let diffBlob = null;
  if (!split.inline) {
    const tmp = path.join(os.tmpdir(), `tonk-diff-${process.pid}-${Date.now()}`);
    fs.writeFileSync(tmp, scan.text);
    try {
      diffBlob = blobAdd(space, tmp, env);
      diff = null;
    } finally {
      fs.rmSync(tmp, { force: true });
    }
  }

  const doc = buildChangeNotation({ ...rec, redacted: scan.redacted }, { diff, diffBlob });
  // $DATA_ROOT/locks/<space>.lock (DATA_ROOT set by core before calling); the
  // critical section is one synchronous local eval, so R2's sync withLock is
  // fine. tonk's own revision.lock can still reject with exit 4 — retry that.
  let res;
  withLock(lockPathFor(space), () => {
    for (let attempt = 1; attempt <= 4; attempt++) {
      res = evalNoSync(space, doc, env);
      if (!res || res.code !== 4) break;
      const until = Date.now() + 150 * attempt;
      while (Date.now() < until) {}
    }
  });
  if (res && res.code !== 0) {
    throw new Error(`tonk eval --no-sync failed (${res.code}): ${(res.stderr || "").trim()}`);
  }
  return { written: true, skipped: false, redacted: scan.redacted, blob: diffBlob, doc };
}

/** session-start write (contracts/records.md §session). */
export function buildSessionStartDoc(rec) {
  return [
    "session!:",
    `  id: ${y(rec.session)}`,
    `  agent: ${y(rec.agent)}`,
    `  harness: ${kw(rec.harness || "vibe")}`,
    `  project: ${y(rec.project)}`,
    `  started: ${y(rec.started)}`,
    "  changes: 0",
    "",
  ].join("\n");
}

/** session-end: re-assert the SAME entity (query-bind this: ?s). */
export function buildSessionEndDoc(rec) {
  return [
    "session:",
    "  this: ?s",
    `  id: ${y(rec.session)}`,
    "",
    "session!:",
    "  this: ?s",
    `  ended: ${y(rec.ended)}`,
    `  changes: ${ynat(rec.changes)}`,
    "",
  ].join("\n");
}

export async function writeSessionStart(space, rec, env, root) {
  const doc = buildSessionStartDoc(rec);
  let res;
  withLock(lockPathFor(space), () => {
    for (let attempt = 1; attempt <= 4; attempt++) {
      res = evalNoSync(space, doc, env);
      if (!res || res.code !== 4) break;
      const until = Date.now() + 150 * attempt;
      while (Date.now() < until) {}
    }
  });
  if (res && res.code !== 0) throw new Error(`tonk eval --no-sync (session) failed (${res.code}): ${(res.stderr || "").trim()}`);
  return { written: true, doc };
}

export async function writeSessionEnd(space, rec, env, root) {
  const doc = buildSessionEndDoc(rec);
  let res;
  withLock(lockPathFor(space), () => {
    for (let attempt = 1; attempt <= 4; attempt++) {
      res = evalNoSync(space, doc, env);
      if (!res || res.code !== 4) break;
      const until = Date.now() + 150 * attempt;
      while (Date.now() < until) {}
    }
  });
  if (res && res.code !== 0) throw new Error(`tonk eval --no-sync (session-end) failed (${res.code}): ${(res.stderr || "").trim()}`);
  return { written: true, doc };
}
