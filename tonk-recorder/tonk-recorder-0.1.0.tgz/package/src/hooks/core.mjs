// Harness-neutral hook core (SPEC §6.3, contracts/hooks.md). Entry:
// handleEvent(payload, opts). Fail-open everywhere: exit 0, print nothing.
//
// Every hook (§6.1): resolve the space (--space > TONK_SPACE > nearest
// ancestor binding in tonk's spaces.json registry — read directly so the
// unbound no-op is <100 ms with zero tonk calls). No binding → exit 0,
// record nothing. Not a git repo → one warning per session, record nothing.
// Active branch ≠ main → no-op.

import { resolveSpace } from "./binding.mjs";
import {
  snapshotTree, diffTrees, isGitRepo, currentBranch, headCommit, projectName,
} from "../snapshot/tool.mjs";
import {
  dataRoot, paths, readTree, writeTree, loadSessionState, saveSessionState,
  stashPrompt, getPrompt, clearPrompts,
} from "./state.mjs";
import { writeChange, writeSessionStart, writeSessionEnd } from "./writer.mjs";
import { checkpointSync, shouldCheckpoint } from "../writer/tool.mjs"; // R2 (landed)
import { buildSessionStartContext, updateNotice } from "./context.mjs";
import { formatOutput } from "./adapters.mjs";

const CHECKPOINT_INTERVAL_DEFAULT = 10; // SPEC §11.9 default

export async function handleEvent(payload, { env = process.env, spaceArg, now = () => new Date().toISOString() } = {}) {
  const harness = payload.harness || env.TONK_HARNESS || "vibe";
  const empty = { code: 0, stdout: "" };

  // §6.1 binding rule — first and fast (pure local fs reads).
  const binding = resolveSpace(payload.cwd, { env, spaceArg });
  if (!binding) return empty;
  const space = binding.space;

  const root = dataRoot(env);
  // R2's lockPathFor/dataRoot read process.env.DATA_ROOT — point them at ours
  if (!process.env.DATA_ROOT) process.env.DATA_ROOT = root;
  if (spaceArg && spaceArg !== env.TONK_SPACE) process.env.TONK_SPACE = spaceArg; // --space wins for child tonk calls
  const sessionId = payload.sessionId || "default";
  let sess = loadSessionState(root, sessionId);

  // Not a git repo → one warning per session, record nothing.
  if (!isGitRepo(payload.cwd)) {
    if (!sess.warnedNotGit) {
      sess.warnedNotGit = true;
      saveSessionState(root, sessionId, sess);
      process.stderr.write(`tonk-recorder: ${payload.cwd} is not a git repo; not recording (v1)\n`);
    }
    return empty;
  }

  // Active branch not main (a restored point-in-time branch, §7.2) → no-op.
  const branch = currentBranch(payload.cwd);
  if (branch !== "main") return empty;

  const agentName = payload.agentName || sess.agentName || env.TONK_AGENT_NAME || "unknown";
  sess.agentName = agentName;
  const interval = parseInt(env.TONK_CHECKPOINT_INTERVAL || `${CHECKPOINT_INTERVAL_DEFAULT}`, 10);
  const sync = () => checkpointSync({ cwd: payload.cwd });

  try {
    switch (payload.event) {
      case "session-start": {
        const tree = snapshotTree(payload.cwd, paths.index(root, sessionId));
        writeTree(root, sessionId, tree);
        sess.turns = sess.turns || 0;
        saveSessionState(root, sessionId, sess);
        // session record (started, changes: 0) — one local eval
        await writeSessionStart(space, {
          session: sessionId, agent: agentName, harness, project: projectName(payload.cwd), started: now(),
        }, env, root);
        // checkpoint sync (network allowed here) + update check
        sync();
        sess.lastCheckpointAt = now();
        saveSessionState(root, sessionId, sess);

        const systemMessage = updateNotice({ space, localVersion: env.TONK_RECORDER_VERSION || "0.1.0", env });
        const additionalContext = buildSessionStartContext({
          space,
          agentName,
          lastSeenOtherAgentAt: sess.lastSeenOtherAgentAt || null,
          ageTurns: 0,
          env: { ...env, __CWD: payload.cwd },
          cwd: payload.cwd,
        });
        return { code: 0, stdout: formatOutput(harness, "session-start", { additionalContext, systemMessage }) };
      }

      case "pre-agent": {
        if (payload.turnId != null && payload.prompt != null) {
          stashPrompt(root, sessionId, payload.turnId, payload.prompt, now());
        }
        return empty; // no rewrite, no context
      }

      case "post-agent": {
        sess.turns = (sess.turns || 0) + 1;
        // Subagent sessions never get session_start (Vibe), so baseline their
        // first turn on the parent session's snapshot (SPEC §4.1, §11.4).
        const prev = readTree(root, sessionId) ?? (payload.parentSessionId ? readTree(root, payload.parentSessionId) : null);
        const next = snapshotTree(payload.cwd, paths.index(root, sessionId));
        if (!prev) {
          writeTree(root, sessionId, next); // session-start was missed; record nothing this turn
          saveSessionState(root, sessionId, sess);
          return empty;
        }
        const d = diffTrees(payload.cwd, prev, next);
        if (!d.empty) {
          const rec = {
            session: sessionId,
            turn: payload.turnId || `turn-${sess.turns}`,
            parentSession: payload.parentSessionId || undefined,
            agent: agentName,
            harness,
            prompt: payload.turnId != null ? getPrompt(root, sessionId, payload.turnId) : null,
            response: payload.responseText ?? null,
            project: projectName(payload.cwd),
            branch,
            base: prev,
            head: next,
            commit: headCommit(payload.cwd),
            files: d.files,
            linesAdded: d.totals.added,
            linesRemoved: d.totals.removed,
            diff: d.diff,
            redacted: false,
            at: now(),
          };
          const w = await writeChange(space, rec, env, root); // ONE local tonk eval --no-sync, no network
          if (w.written) sess.changes = (sess.changes || 0) + 1;
        }
        writeTree(root, sessionId, next); // snapshot becomes prev
        // checkpoint every N turns (default 10) — the ONLY post-agent network path
        if (shouldCheckpoint(sess.turns, interval)) {
          sync();
          sess.lastCheckpointAt = now();
        }
        saveSessionState(root, sessionId, sess);
        return empty; // post-agent: no stdout
      }

      case "session-end": {
        const ended = now();
        // count changes this session from local state: count written turns
        // (tracked implicitly by prompts/turns; we store the counter on the
        //  session state — incremented per written change below)
        await writeSessionEnd(space, {
          session: sessionId, agent: agentName, harness,
          project: projectName(payload.cwd), ended,
          changes: sess.changes || 0,
        }, env, root);
        sync();
        sess.lastCheckpointAt = ended;
        clearPrompts(root, sessionId);
        saveSessionState(root, sessionId, sess);
        return empty; // session-end output ignored
      }

      default:
        return empty;
    }
  } catch (err) {
    // fail open (contracts/hooks.md): never block the harness
    process.stderr.write(`tonk-recorder: hook ${payload.event} failed open: ${err && err.message ? err.message : err}\n`);
    return empty;
  }
}
