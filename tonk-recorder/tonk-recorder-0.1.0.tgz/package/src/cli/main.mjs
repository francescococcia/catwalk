// tonk-recorder CLI dispatch — SPEC §3 command table.
import { PKG_NAME, PKG_VERSION } from "./paths.mjs";
import { cmdNew } from "./commands/new.mjs";
import { cmdJoin } from "./commands/join.mjs";
import { cmdInvite, cmdStatus, cmdSync, cmdHook, cmdInstructions, cmdUninstall } from "./commands/misc.mjs";
import { cmdPublish } from "./commands/publish.mjs";
import { runBuild } from "./build.mjs";

const USAGE = `${PKG_NAME} v${PKG_VERSION} — records every agent's code changes into a bound Tonk space.

usage: ${PKG_NAME} <command> [args]

commands:
  new <name> [--agent-name <n>] [--harness vibe|claude]
                        create + bind a space, publish the recorder logic into it,
                        install hooks into this harness, print the invite paste line
  join '<link>' [--agent-name <n>] [--harness vibe|claude]
                        join a space, fetch + verify (sha256, trusted publisher) the
                        logic, install hooks
  invite                print a fresh invite link + the paste line
  status                binding, sync state, hook state, update availability
  sync                  one checkpoint now: tonk pull + tonk push (SPEC §6.5)
  hook <event>          harness entry point: session-start|pre-agent|post-agent|session-end
  instructions          print how to add a decision by hand with plain tonk commands
  publish [--file F] [--version V] [--changelog "line"]
                        store a new logic version in the space (trusted publishers only)
  uninstall             remove the plugin / managed hooks and local state
  build                 (internal) rebuild the self-contained dist/tool.mjs
  version               print the wrapper version

Environment:
  TONK_BIN              tonk binary to run (dev/branch builds, tests). Default: the
                        pinned node_modules/@tonk/cli — never whatever is on PATH.
  TONK_SPACE / --space  handled by tonk itself (precedence per tonk --help).
`;

export async function main(argv, ctx = {}) {
  const [cmd, ...rest] = argv;
  try {
    switch (cmd) {
      case "new": return await cmdNew(rest, ctx);
      case "join": return await cmdJoin(rest, ctx);
      case "invite": return await cmdInvite(rest, ctx);
      case "status": return await cmdStatus(rest, ctx);
      case "sync": return await cmdSync(rest, ctx);
      case "hook": return await cmdHook(rest, ctx);
      case "instructions": return await cmdInstructions(rest, ctx);
      case "publish": return await cmdPublish(rest, ctx);
      case "uninstall": return await cmdUninstall(rest, ctx);
      case "build": {
        const r = runBuild();
        console.log(`built ${r.outFile} (${r.bytes} bytes)`);
        return 0;
      }
      case "version":
      case "--version":
        console.log(PKG_VERSION);
        return 0;
      case undefined:
      case "help":
      case "--help":
      case "-h":
        process.stdout.write(USAGE);
        return cmd === undefined ? 1 : 0;
      default: {
        console.error(`${PKG_NAME}: unknown command '${cmd}'\n`);
        process.stderr.write(USAGE);
        return 1;
      }
    }
  } catch (err) {
    console.error(`tonk-recorder: ${err && err.message ? err.message : err}`);
    return err.exitCode ?? 1;
  }
}
