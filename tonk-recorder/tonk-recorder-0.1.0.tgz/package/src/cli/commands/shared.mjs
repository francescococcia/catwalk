// Shared helpers for the CLI commands.
import fs from "node:fs";
import path from "node:path";
import { PKG_ROOT, PKG_NAME, PKG_VERSION, DIST_TOOL, homeDir } from "../paths.mjs";
import { CONTRACTS } from "../contracts.mjs";
import { tonkOk } from "../tonk.mjs";
import { runBuild } from "../build.mjs";

/** Minimal flag parser: positional args + --key value / --flag. */
export function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith("--")) out[key] = true;
      else { out[key] = next; i++; }
    } else out._.push(a);
  }
  return out;
}

export function opt(args, name) {
  return args[name] === undefined || args[name] === true ? undefined : args[name];
}

/** The invite paste line (SPEC §3.2). The link is printed to stdout ONLY —
 *  never written into files, commits, records or AGENTS.md (SPEC §8). */
export function pasteLine(link, agentName = "<name>") {
  return `npx --yes ${PKG_NAME} join '${link}' --agent-name ${agentName}`;
}

/** Mint an invite link via tonk; fall back to --no-shorten (offline-safe). */
export async function inviteLink(opts = {}) {
  let r;
  try {
    r = await tonkOk(["invite"], opts);
  } catch {
    r = await tonkOk(["invite", "--no-shorten"], opts); // documented offline mint
  }
  const line = r.stdout.trim().split("\n").filter(Boolean).pop();
  if (!line || !/^https?:\/\//.test(line)) {
    const err = new Error(`could not parse invite link from \`tonk invite\` output`);
    err.exitCode = 1;
    throw err;
  }
  return line.trim();
}

/** Resolve the structure pack (S1): env override → package packs/ → embedded stub. */
export function resolveStructurePack() {
  if (process.env.TONK_RECORDER_PACK) return process.env.TONK_RECORDER_PACK;
  const inPkg = path.join(PKG_ROOT, CONTRACTS.componentPaths.structurePack);
  if (fs.existsSync(inPkg)) return inPkg;
  return path.join(PKG_ROOT, "src", "cli", "logic", "structure-pack.notation");
}

/** Resolve the R4 decision-instructions text: env → package instructions/ → stub. */
export function resolveInstructions() {
  if (process.env.TONK_RECORDER_INSTRUCTIONS) return fs.readFileSync(process.env.TONK_RECORDER_INSTRUCTIONS, "utf8");
  const inPkg = path.join(PKG_ROOT, CONTRACTS.componentPaths.instructions);
  if (fs.existsSync(inPkg)) return fs.readFileSync(inPkg, "utf8");
  return fs.readFileSync(path.join(PKG_ROOT, "src", "cli", "logic", "instructions.md"), "utf8");
}

/** Ensure dist/tool.mjs exists (build on demand). */
export function ensureDist() {
  if (!fs.existsSync(DIST_TOOL)) runBuild();
  return DIST_TOOL;
}

export function home(env = process.env) {
  return homeDir(env);
}

export { PKG_NAME, PKG_VERSION };
