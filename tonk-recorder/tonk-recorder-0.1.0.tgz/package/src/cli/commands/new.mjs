// `<wrapper> new <name>` — SPEC §3.1:
//   1. tonk space new <name> (creates, registers, binds this project folder)
//   2. load the structure pack (idempotent, S1) via tonk eval --no-sync
//   3. publish the logic into the space (B1: blob + tool record + trusted
//      publisher for the creator + AGENTS.md bootstrap block)
//   4. install the hooks into this harness (H1 via contract / §4.1 layout)
//   5. print the invite paste line
import fs from "node:fs";
import { tonkOk } from "../tonk.mjs";
import { installPlugin } from "../install.mjs";
import { publishLogic } from "../../publish/publish.mjs";
import { parseArgs, opt, pasteLine, inviteLink, resolveStructurePack, resolveInstructions, ensureDist, home, PKG_VERSION } from "./shared.mjs";

export async function cmdNew(argv, { env = process.env, cwd = process.cwd() } = {}) {
  const args = parseArgs(argv);
  const name = args._[0];
  if (!name) {
    const err = new Error("usage: tonk-recorder new <space-name> [--agent-name <name>] [--harness vibe|claude]");
    err.exitCode = 1;
    throw err;
  }
  const agentName = opt(args, "agent-name") ?? env.USER ?? "agent";
  const harness = opt(args, "harness") ?? "vibe";
  const opts = { env, cwd };

  // 1. create + bind the space
  await tonkOk(["space", "new", name], opts);

  // 2. structure pack (idempotent)
  await tonkOk(["eval", "--no-sync", resolveStructurePack()], opts);

  // 3. publish the self-contained logic into the space (build dist if needed)
  const distTool = ensureDist();
  const pub = await publishLogic({
    file: distTool,
    version: PKG_VERSION,
    changelog: `v${PKG_VERSION}: initial publish by ${agentName}`,
    markCreatorTrusted: true, // SPEC §3.1 step 3: creator becomes trusted publisher
    instructionsText: resolveInstructions(),
    env,
    cwd,
  });

  // 4. install hooks into this harness
  await installPlugin({
    home: home(env),
    version: pub.version,
    toolSource: fs.readFileSync(distTool),
    harness,
    env,
  });

  // 5. print the paste line (link goes to stdout only — SPEC §8)
  const link = await inviteLink(opts);
  console.log(`space '${name}' created and bound to ${cwd}`);
  console.log(`recorder logic v${pub.version} published (${pub.blobRef}, sha256 ${pub.sha256.slice(0, 12)}…) and installed into harness '${harness}'`);
  console.log("");
  console.log("Invite others with this one line:");
  console.log(`  ${pasteLine(link, "<their-agent-name>")}`);
  return 0;
}
